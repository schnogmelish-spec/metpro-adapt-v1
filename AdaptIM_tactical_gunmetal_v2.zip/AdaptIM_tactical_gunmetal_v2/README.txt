AdaptIM Tactical Gunmetal v2

Replace only adaptim_v4.html in GitHub.
No app.py change is required.

Visual-only changes:
- Tactical intake selector 3/4/5/6 centered evenly across the bar.
- Dark gunmetal card and control surfaces.
- Brighter machined-steel edge highlights.
- Existing Tactical avatar artwork retained with a tougher metallic/white-highlight treatment.
- Electric blue and ROSC-red accents preserved.

No JavaScript/application logic was changed.
